package com.michael.monnifypayment

fun main() {
    for (r in 1..5) {
        for (c in  1..r) {
            print("*")
        }
        println("")
    }
}